#creating a button class
#class is defined by a constructor (__init__)
#variables in the init() are called parameters
#buttons dont do anything unless given an action

from graphics import *

class Button:#class is a definition of an object

    #p1 and p2 are the two points

    def __init__(self, win, p1, p2, color, text):
        self.color = color
        self.text = text

        x1 = p1.getX()
        x2 = p2.getX()
        y1 = p1.getY()
        y2 = p2.getY()
        self.minX = x1
        self.maxX = x2
        self.minY = y1
        self.maxY = y2
        
        center = Point((x1 + x2)/2, (y1 + y2)/2)
        
        self.body = Rectangle(p1, p2)
        self.body.draw(win)
        self.body.setFill(self.color)

        self.T = Text(center, self.text)
        self.T.draw(win)

    def isClicked(self, p):
        x = p.getX()
        y = p.getY()

        if x > self.minX:
            if x < self.maxX:
                if y > self.minY:
                    if y < self.maxY:
                        return True

        return False











        
